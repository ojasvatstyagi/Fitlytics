// === deleteWorkoutFunction ===
// Node.js 22.x compatible with aws-sdk v2 bundled manually

const AWS = require("aws-sdk");
const dynamo = new AWS.DynamoDB.DocumentClient();

exports.handler = async (event) => {
  try {
    const { workoutID, userID } = event.queryStringParameters;

    const params = {
      TableName: "WorkoutLogs",
      Key: { userID, workoutID },
    };

    await dynamo.delete(params).promise();
    return {
      statusCode: 200,
      body: JSON.stringify({ message: "Workout deleted successfully" }),
    };
  } catch (err) {
    return {
      statusCode: 500,
      body: JSON.stringify({ error: err.message }),
    };
  }
};
