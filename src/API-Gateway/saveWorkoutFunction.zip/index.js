// saveWorkoutFunction - Node.js 22.x compatible version using aws-sdk v2 (bundled manually)

const AWS = require("aws-sdk");
const { v4: uuidv4 } = require("uuid");

// Initialize clients
const dynamo = new AWS.DynamoDB.DocumentClient();
const sns = new AWS.SNS();

exports.handler = async (event) => {
  console.log("Incoming request:", event);

  try {
    const body = typeof event.body === "string" ? JSON.parse(event.body) : event.body;
    const { userID, workoutName, workoutDate, exercises } = body;
    const workoutID = uuidv4();

    // Prepare DynamoDB PutItem parameters
    const params = {
      TableName: "WorkoutLogs",
      Item: {
        userID,
        workoutID,
        workoutName,
        workoutDate,
        exercises,
      },
    };

    // Save to DynamoDB
    await dynamo.put(params).promise();
    console.log("Workout saved to DynamoDB");

    // Prepare and send SNS notification
    const snsParams = {
      TopicArn: "arn:aws:sns:ap-south-1:862201239884:WorkoutNotifier", // Replace with your actual ARN
      Subject: "New Workout Logged",
      Message: `User ${userID} logged a workout: "${workoutName}" on ${workoutDate}`,
    };
    // console.log("SNS params:", snsParams);

    await sns.publish(snsParams).promise();
    console.log("SNS notification sent");

    return {
      statusCode: 200,
      body: JSON.stringify({
        message: "Workout saved and notification sent",
        workoutID,
      }),
    };
  } catch (error) {
    console.error("Error in Lambda:", error);
    return {
      statusCode: 500,
      body: JSON.stringify({
        error: "Failed to save workout or send notification",
      }),
    };
  }
};