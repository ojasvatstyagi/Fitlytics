// === updateWorkoutFunction ===
const AWS3 = require("aws-sdk");
const dynamo3 = new AWS3.DynamoDB.DocumentClient();

exports.handler = async (event) => {
  try {
    const body = JSON.parse(event.body);
    const { userID, workoutID, workoutName, workoutDate, exercises } = body;

    const params = {
      TableName: "WorkoutLogs",
      Item: {
        userID,
        workoutID,
        workoutName,
        workoutDate,
        exercises,
      },
    };

    await dynamo3.put(params).promise();
    return {
      statusCode: 200,
      body: JSON.stringify({ message: "Workout updated successfully" }),
    };
  } catch (err) {
    return {
      statusCode: 500,
      body: JSON.stringify({ error: err.message }),
    };
  }
};