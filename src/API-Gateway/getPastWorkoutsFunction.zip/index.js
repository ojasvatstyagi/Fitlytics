const AWS = require("aws-sdk");
const dynamo = new AWS.DynamoDB.DocumentClient();

exports.handler = async (event) => {
  console.log("Incoming event:", JSON.stringify(event));

  try {
    const email = event.queryStringParameters?.email;

    if (!email) {
      return {
        statusCode: 400,
        headers: {
          "Access-Control-Allow-Origin": "*",
        },
        body: JSON.stringify({ error: "Missing email parameter." }),
      };
    }

    const params = {
      TableName: "WorkoutLogs",
      KeyConditionExpression: "userID = :email",
      ExpressionAttributeValues: {
        ":email": email,
      },
    };

    const data = await dynamo.query(params).promise();

    return {
      statusCode: 200,
      headers: {
        "Access-Control-Allow-Origin": "*", // ✅ Required for CORS
      },
      body: JSON.stringify(data.Items),
    };
  } catch (err) {
    console.error("Error querying DynamoDB:", err);

    return {
      statusCode: 500,
      headers: {
        "Access-Control-Allow-Origin": "*", // ✅ Required even for errors
      },
      body: JSON.stringify({ error: err.message }),
    };
  }
};
